
import rippet

rippet.main()
