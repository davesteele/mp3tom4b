
import mp3tom4b

mp3tom4b.main()
